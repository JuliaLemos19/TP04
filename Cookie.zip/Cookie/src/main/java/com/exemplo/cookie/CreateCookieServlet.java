package com.exemplo.cookie;

//Julia Lemos

import java.io.IOException;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/create-cookie")
public class CreateCookieServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        
        String nomeUsuario = request.getParameter("nomeUsuario");
        

        Cookie cookie = new Cookie("user-name", nomeUsuario);
        cookie.setMaxAge(60 * 60);
        response.addCookie(cookie);


        response.setContentType("text/html");
        response.getWriter().write("<h2>Cookie criado com sucesso para: " + nomeUsuario + "!</h2>");
        response.getWriter().write("<a href='read-cookie'>Ler cookie</a><br>");
        response.getWriter().write("<a href='delete-cookie'>Deletar cookie</a>");
    }
}
