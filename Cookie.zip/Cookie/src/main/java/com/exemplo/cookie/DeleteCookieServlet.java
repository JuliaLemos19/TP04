package com.exemplo.cookie;

//Julia Lemos

import java.io.IOException;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/delete-cookie")
public class DeleteCookieServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        Cookie cookie = new Cookie("user-name", "");
        cookie.setMaxAge(0);
        response.addCookie(cookie);

        response.setContentType("text/html");
        response.getWriter().write("<h2>Cookie deletado!</h2>");
        response.getWriter().write("<a href='index.jsp'>Criar cookie</a><br>");
        response.getWriter().write("<a href='read-cookie'>Ler cookie</a>");
    }
}
