package com.exemplo.cookie;

//Julia Lemos

import java.io.IOException;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/read-cookie")
public class ReadCookieServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        Cookie[] cookies = request.getCookies();
        String userName = "Desconhecido";

        if (cookies != null) {
            for (Cookie c : cookies) {
                if ("user-name".equals(c.getName())) {
                    userName = c.getValue();
                    break;
                }
            }
        }

        response.setContentType("text/html");
        response.getWriter().write("<h2>Olá, " + userName + "!</h2>");
        response.getWriter().write("<a href='delete-cookie'>Deletar cookie</a>");
    }
}

 